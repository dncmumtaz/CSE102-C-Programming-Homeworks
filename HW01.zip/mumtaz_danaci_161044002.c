						/*CSE 102 Programming Assignment 1*/
						/*MUMTAZ DANACI*/
						/*16104002*/
#include <stdio.h>
#define zeroo 0.001

int main() {
	float tempx, tempy, sumx=0, sumy=0;
	float midpoint_x, midpoint_y; /* midpoint coordinates */
	float average1x, average1y, average2x, average2y; /* average points*/
	float slope, perpentecular_slope; /*slope ,perpentecular_slope is -1 time with slope*/
	float i, test_x=1, test_y=1;	/*test point values*/	
	float dvd1, dvd2, d;
	float X, Y;
	
	printf("Enter class1 numbers:\n");
	for(i = 0; i<10; i++){	/*pre-defined number of points for class 1*/
		tempx = 0;
		tempy = 0;
		scanf("%f %f",&tempx, &tempy);
		sumx += tempx;
		sumy += tempy;
	}
	average1x = sumx;
	average1y = sumy;
	average1x /= 10;
	average1y /= 10;
	/*The four lines calculate the average of class1*/
	
	sumx = 0;
	sumy = 0;
	printf("Enter class2 numbers:\n");
	for(i = 0; i<10; i++){	/*pre-defined number of points for class 2*/
		tempx = 0;
		tempy = 0;
		scanf("%f %f",&tempx, &tempy);
		sumx += tempx;
		sumy += tempy;
	}	
	average2x = sumx;
	average2y = sumy;
	average2x /= 10;
	average2y /= 10;
	/*The four lines calculate the average of class2*/

	midpoint_x = (average1x + average2x) / 2;/*midpoint of the connecting line*/
	midpoint_y = (average1y + average2y) / 2;
	dvd2 = average2x - average1x;
	dvd1 = average2y - average1y;
	if( dvd2 == 0){	/*This condition prevent divide by zero*/
		dvd2 = zeroo;
	}
	if(average2y - average1y == 0){/*This condition prevent divide by zero*/
		dvd1 = zeroo;
	}
	slope = dvd1 / dvd2; /*slope of connecting line*/
	perpentecular_slope = -1 * slope;		/*slope of seperate line*/
//	perpentecular_slope = (Y - midpoint_y)/(X - midpoint_x);/*seperate line*/
	printf("enter a test coordinate\n");	
	while(1){	/*testing loop*/
		test_x = i;
		scanf("%f %f",&test_x,&test_y); /* takes point from user*/	
		d = (test_x-midpoint_x)*(average1y-midpoint_y)-(test_y-midpoint_y)*(average1x-midpoint_x);				
		if(test_x==i){/*User enters something not expected Program quits.*/
			break;
			}				
		if(d<0){
			printf("class 2\n");
		}
		else
			printf("class 1\n");
	}
return 0;
}
