				/*CSE102 - homework II*/
				/*MUMTAZ DANACI*/
				/*16044002*/
#include <stdio.h>

#define p1 0.5 /*pre-defined numbers*/
#define p2 20 /*pre-defined numbers*/
float control(float a, float b, float n);/*formula function*/
void writeToFile(FILE * eroglu, float q, float *ave, float arr[100][1000] );/*function which write to file*/
int main(){	/*main function*/
	FILE *mete, *eroglu;		
	float n, a, b=0, div=2, tempp,ftemp, sum = 0;
	int i=1,q = 0,swapped, y,  p, j=0, k=1, temp;
	float ar[100][1000], ave[1000];/*ave is average array, ar is main array which holds all the values*/
	
	mete = fopen("input.txt","r");
	eroglu = fopen("output.txt","w");
	fscanf(mete,"%f",&a);/*first number*/	
	ftemp = a;
	sum = sum + a;	
	
	while(!feof(mete)){	
			
		k++;
		fscanf(mete,"%f ",&n);		/*to take from input.txt*/			
		sum += n;					/*sum for average*/
		b = sum / div;				/*b is average in the formula*/
		temp = control(a, b, n);	/*control function*/
		if(temp == 1){				/*if it is true, write same row*/
			a = sum / div;		
			ar[q][k] = n;			
		}
		
		else{						/*if is not true, pass other row*/
				
			a = n;					/*a is averaga in the formula*/
			sum = a;				
			div = 1;				/*for find the averages*/
			ar[q][1] = k+1;			/*seperated the second column for number of element in each chunk */
			k=2;					/*k is asigned to second column */
			i++;
			q++;
			ar[q][2] = n;
		}						
		ave[q] = a;	
		
		div++;
		
	}
	ave[q] = b;
	ar[q][1] = k+2;
	ar[0][1] +=1;
	ar[0][((int)ar[0][1])-2] = ftemp;

	for( p=0; p<=q; ++p){	/*assign average on fisrt column of ar array*/
		ar[p][0] = ave[p];		 	
	}
	
	
 	 swapped = 0;
     for (y = 0; y < 3; y++) {	/*sort process for average array(ave)*/
     	swapped = 0;
 		 for (j = 0 ; j < 3-y; j++) {
				   				
   				if (ave[j] > ave[j+1]) {
					tempp = ave[j];
					ave[j] = ave[j+1];
					ave[j+1] = tempp;
					swapped = 1;
				
			}
		 }
		if(!swapped) {
         break;
      }
	
	}
	
	writeToFile(eroglu,q,ave,ar);
	fclose(mete);
	fclose(eroglu);
return 0;
}

float control(float a, float b, float n){ /*formula function*/

	if(!(b >a *(1 + p1 ) || b < a*(1-p1) || a > n*p2 || a < n/p2 )) /*the given formula*/
		return 1;
	else 
		return -1;
}

void writeToFile(FILE * eroglu, float q, float *ave, float arr[100][1000] ){/*function which write to file*/
	
	int i, j, k;
	
	q++;
	for( i = 0; i<=q; ++i){
		for( j=0; j<=q; ++j){
			if(ave[i] == arr[j][0]){/*this condition compare ave and second column of ar */
				for( k=0; k<(arr[j][1]-3); ++k){ 	/*if it is true , write the row on file */
					fprintf(eroglu,"%f ",arr[j][k+2]);
				}
					fprintf(eroglu,"\n");
			}
		}
	}

}
























