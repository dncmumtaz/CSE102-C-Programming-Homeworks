/**************************************************************************/
/*                           Homework III                                 */
/*                          Mumtaz Danaci                                 */
/*                           161044002                                    */
/*This program finds searched word in text file.                          */
/**************************************************************************/

/**************************************************************************/
/*The readFirst function takes the words input1.txt and assigns           */
/*to ar1, respectively. The assignToArray function takes the character    */
/*from input2.txt file and assigns to array ar2. The search function searches*/
/*in array ar2.                                                           */

#include <stdio.h>
#define sizear1 10 /*maximum word length of  input1.txt*/
#define sizear2one 100/*maximum row of input2.txt*/
#define sizear2two 250/*maximum column of input2.txt*/

int readFirst(FILE *mete, char ar1[sizear1]);
void assignToArray(FILE *eroglu, char ar2[sizear2one][sizear2two]);
void search(FILE *write, char ar1[sizear1], char ar2[sizear2one][sizear2two], int number);

int main(){/*main function*/

	FILE * mete,*eroglu, *write;/*File pointers*/
	int  count=0;				/*count is lenght of words in array ar1.*/	
	char ar2[sizear2one][sizear2two], ar1[sizear1];
	mete = fopen("input1.txt","r");
	eroglu = fopen("input2.txt","r");
	write = fopen("output.txt","w");
	assignToArray(eroglu,ar2);
	
	while(!feof(mete)){/*this loop searches words, respectively.*/
		count = readFirst(mete,ar1);
		search(write, ar1, ar2,count);	        
	}
	fclose(write);
	fclose(mete);
	fclose(eroglu);
	return 0;
}

int readFirst(FILE *mete, char ar1[sizear1]){
	int i;	
	fscanf(mete," %s",ar1);
	for(i=0; i<sizear1;i++){
		if(ar1[i] == '\0'|| feof(mete))
			break;     
	}
	return i;
}

void assignToArray(FILE *eroglu, char ar2[sizear2one][sizear2two]){
	int i;
	for(i=0; i<sizear2one; i++){
		fscanf(eroglu," %s",ar2[i]);		
	}
}

void search(FILE *write, char ar1[sizear1], char ar2[sizear2one][sizear2two], int number){
	int i=0, j, k, m, n,r=0, temp1, temp2, temp3;
	char control[sizear1];
	for(j=0; j<sizear2one; j++){
		temp1 = j+1;		
		for(k=0; k<sizear2two; k++){/*64-83,the loop  for horizantal words */
			temp2 = k+1;
			if(ar2[j][k] == '\0')
				break;
			if(sizear2two - k <= number)
			    break;
			if(ar1[i] != ar2[j][k])
				i=0;
			while(ar1[i] == ar2[j][k]){
				i++;
				k++;
				if(i == number){/*if number of ar1 character's is equel to i, write to file*/
					for(m = 0; m< number; m++)
						fprintf(write,"%c",ar1[m]);
					fprintf(write," (%d,%d) Horizontal\n",temp1,temp2);
					i=0;
					break;
				}				
			}			
		}
		i=0;
		temp3 = j;
		r =0;
		for(n=0; n<sizear2two; n++){	/*87-105 , the for vertical words*/	
			if(ar2[temp3][n] == '\0')
				break;			
				i=0;			
			while(ar1[r] == ar2[temp3][n]){
				i++;
				temp3++;
				control[i] = ar1[r];
				r++;
				if(i == number ){/*if number of ar1 character's is equel to i, write to file*/
					for(m = 1; m< number+1; m++)
						fprintf(write,"%c",control[m]);
					fprintf(write," (%d,%d) Vertical\n",temp1,n+1);
					i=0;
					break;
				}			
			}					
		}
	}
}










