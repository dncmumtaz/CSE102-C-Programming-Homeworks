/******************************************/
/*            MUMTAZ DANACI               */
/*			  161044002                   */
/*  		  homewrok IV                 */
/*                                        */
/* this program calculates the given func-*/
/* polynomial                             */



#include <stdio.h>/*my libraries*/
#include <string.h>
#include <math.h>

#define size1 10
#define size2 1000
int readVal(FILE *readValues,double val[size1]);/*to assign value  to val array from values.txt*/ 
int readPoly(FILE *readPolynomial,char pol[size2]);/*to assign value  to pol array from polynomial.txt*/
float findXresult(double val[size1],char pol[size2], double result[20], int index, int numberOfArray, FILE *write);
/* to do processes */

int main()
{
	FILE *readValues, *readPolynomial, *write;/*FIle pointers*/
	readValues = fopen("values.txt","r");	
	readPolynomial = fopen("polynomial.txt","r");
	write = fopen("evaluations.txt","w");
	int numberOfArray, index;/*numberofarray is size of polynomial.txt*/
	double  val[size1], result[20];	
	char pol[size2];/*character array*/
	readVal(readValues,val);
	numberOfArray = readPoly(readPolynomial,pol);

	findXresult(val, pol, result, index, numberOfArray, write);	

	fclose(readValues);/* for close to file */
	fclose(readPolynomial);
	fclose(write);	
	return 0;
}

int readVal(FILE *readValues,double val[size1]){/*to assign value  to val array from values.txt*/ 
	int i ;
	for(i = 1; i < size1 + 1; i++){
		if(!feof(readValues)){
			fscanf(readValues,"%lf",&val[i]);					
		}	
		else 
			break;	
	}
	val[0] = i;

	for(int m = 0; m<val[0]+1; m++){

	
	}
} 
int readPoly(FILE *readPolynomial,char pol[size2]){/*to assign value  to pol array from polynomial.txt*/
	
	int i=0;
		
	while(fscanf(readPolynomial,"%c",&(pol[i])) != EOF){/*to clear spaces*/	
		if(pol[i] != ' ' )i++;	
	}
	
	return i;
}

float findXresult(double val[size1],char pol[size2], double result[20], int index, int numberOfArray, FILE * write){
	int j,control=0,control2=0, a =0, m;
	double pre, power, temp,tempsum=0, temptotal=0;

	for(m=1; m<val[0]; m++){
			
		temptotal=0;
		index =m;
		for(j= 0; j< numberOfArray; j++){

			if(pol[j-1] == '-' || pol[j] == '-'){/*for control minus operator*/	
				control2 = -1;
			}

			else if(pol[j] == '+')  /*for control plus operator*/
				control2 = +1;
			else 
				control2 = 0;
			control = 0;
			sscanf(&pol[j],"%lf", &pre);
			while(pol[j] >= '0' && pol[j] <= '9'){
				++j;		
			}
		
			if(pol[j] == 'x'){/*for control x character*/
				if(pol[j-1] >= '0' && pol[j-1] <= '9') control++;
				if(pol[j+1] == '^'){
					sscanf(&pol[j+2],"%lf", &power);
					result[a] = pow(val[index],power);
					j = j+2;
					while(pol[j] <47 && pol[j] > 58)
						j++;
				}
				else{
					result[a] = val[index];
				}	
				if(control != 0){
					tempsum= result[a] * pre;

				}
				else if(control == 0){
					tempsum =result[a];
				
				}
			}
			if(control2 == -1)
				tempsum*=-1;
		
				temptotal +=tempsum;		
				++j; 
	
		}
		
		temptotal-=5*val[m];
		fprintf(write,"%.2f\n", temptotal);
	}


}

